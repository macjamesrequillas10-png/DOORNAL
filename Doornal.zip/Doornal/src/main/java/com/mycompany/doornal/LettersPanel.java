/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.doornal;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.EmptyBorder;


/**
 *
 * @author Hp
 */



public class LettersPanel extends JPanel {

    private JPanel lettersContainer;
    private JButton addButton;

    // Stores all letters
    private ArrayList<Letter> letters = new ArrayList<>();

    // File where letters are saved
    private final String SAVE_FILE = "letters.dat";

    // Letter data
    private static class Letter implements Serializable {
        String title;
        String message;

        Letter(String title, String message) {
            this.title = title;
            this.message = message;
        }
    }

    public LettersPanel() {

        setLayout(new BorderLayout(20, 20));
        setBackground(new Color(250, 248, 245));
        setBorder(new EmptyBorder(40, 50, 40, 50));

        // TITLE
        JLabel title = new JLabel("Letters");
        title.setFont(new Font("Arial", Font.BOLD, 30));
        add(title, BorderLayout.NORTH);

        // LETTERS CONTAINER
        lettersContainer = new JPanel();
        lettersContainer.setLayout(
                new BoxLayout(lettersContainer, BoxLayout.Y_AXIS)
        );
        lettersContainer.setBackground(new Color(250, 248, 245));

        JScrollPane scrollPane = new JScrollPane(lettersContainer);
        scrollPane.setBorder(null);
        scrollPane.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
        );
        scrollPane.getViewport().setBackground(
                new Color(250, 248, 245)
        );

        add(scrollPane, BorderLayout.CENTER);

        // ADD BUTTON
        addButton = new JButton("+ Add New Letter");
        addButton.setFont(new Font("Arial", Font.BOLD, 15));
        addButton.setFocusPainted(false);

        addButton.addActionListener(e -> openEditor(null));

        JPanel bottomPanel = new JPanel(
                new FlowLayout(FlowLayout.CENTER)
        );
        bottomPanel.setOpaque(false);
        bottomPanel.add(addButton);

        add(bottomPanel, BorderLayout.SOUTH);

        // LOAD SAVED LETTERS
        loadLetters();
        refreshLetters();
    }

    // =====================================
    // SAVE LETTERS TO FILE
    // =====================================

    private void saveLetters() {

        try (ObjectOutputStream output =
                new ObjectOutputStream(
                        new FileOutputStream(SAVE_FILE))) {

            output.writeObject(letters);

        } catch (IOException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Could not save letters: " + e.getMessage()
            );
        }
    }

    // =====================================
    // LOAD LETTERS FROM FILE
    // =====================================

    @SuppressWarnings("unchecked")
    private void loadLetters() {

        File file = new File(SAVE_FILE);

        if (!file.exists()) {
            return;
        }

        try (ObjectInputStream input =
                new ObjectInputStream(
                        new FileInputStream(file))) {

            letters = (ArrayList<Letter>) input.readObject();

        } catch (IOException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Could not load saved letters: " + e.getMessage()
            );
        }
    }

    // =====================================
    // REFRESH LETTER NOTIFICATIONS
    // =====================================

    private void refreshLetters() {

        lettersContainer.removeAll();

        for (Letter letter : letters) {
            addLetterNotification(letter);
        }

        lettersContainer.revalidate();
        lettersContainer.repaint();
    }

    // =====================================
    // CREATE NOTIFICATION CARD
    // =====================================

    private void addLetterNotification(Letter letter) {

        JPanel notification = new JPanel(
                new BorderLayout(10, 5)
        );

        notification.setBackground(Color.WHITE);

        notification.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(220, 215, 210)
                        ),
                        new EmptyBorder(15, 20, 15, 20)
                )
        );

        notification.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 100)
        );

        notification.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel titleLabel = new JLabel(letter.title);
        titleLabel.setFont(
                new Font("Arial", Font.BOLD, 17)
        );

        JLabel previewLabel = new JLabel(
                truncateText(letter.message, 70)
        );

        previewLabel.setFont(
                new Font("Arial", Font.PLAIN, 13)
        );

        notification.add(titleLabel, BorderLayout.NORTH);
        notification.add(previewLabel, BorderLayout.CENTER);

        notification.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );

        notification.addMouseListener(
                new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        viewLetter(letter);
                    }
                }
        );

        lettersContainer.add(notification);
        lettersContainer.add(Box.createVerticalStrut(12));
    }

    // =====================================
    // SHORTEN LETTER PREVIEW
    // =====================================

    private String truncateText(String text, int maxLength) {

        if (text.length() > maxLength) {
            return text.substring(0, maxLength) + "...";
        }

        return text;
    }

    // =====================================
    // VIEW LETTER WINDOW
    // =====================================

    private void viewLetter(Letter letter) {

        JDialog dialog = new JDialog(
                SwingUtilities.getWindowAncestor(this),
                letter.title,
                Dialog.ModalityType.APPLICATION_MODAL
        );

        dialog.setSize(750, 550);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(15, 15));

        dialog.getContentPane().setBackground(
                new Color(250, 248, 245)
        );

        // LETTER TITLE
        JLabel titleLabel = new JLabel(letter.title);
        titleLabel.setFont(
                new Font("Arial", Font.BOLD, 25)
        );

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.setBorder(
                new EmptyBorder(20, 25, 5, 25)
        );
        topPanel.add(titleLabel, BorderLayout.NORTH);

        // LETTER CONTENT
        JTextArea messageArea = new JTextArea(letter.message);
        messageArea.setFont(
                new Font("Arial", Font.PLAIN, 16)
        );
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);
        messageArea.setEditable(false);
        messageArea.setBackground(Color.WHITE);
        messageArea.setBorder(
                new EmptyBorder(15, 15, 15, 15)
        );

        JScrollPane messageScroll = new JScrollPane(messageArea);
        messageScroll.setBorder(
                BorderFactory.createLineBorder(
                        new Color(220, 215, 210)
                )
        );

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(
                new EmptyBorder(0, 25, 10, 25)
        );
        contentPanel.add(messageScroll, BorderLayout.CENTER);

        // EDIT BUTTON
        JButton editButton = new JButton("Edit Letter");
        editButton.setFont(
                new Font("Arial", Font.BOLD, 14)
        );
        editButton.setFocusPainted(false);

        editButton.addActionListener(e -> {
            dialog.dispose();
            openEditor(letter);
        });

        JPanel bottomPanel = new JPanel(
                new FlowLayout(FlowLayout.RIGHT)
        );
        bottomPanel.setOpaque(false);
        bottomPanel.setBorder(
                new EmptyBorder(5, 25, 15, 25)
        );
        bottomPanel.add(editButton);

        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(contentPanel, BorderLayout.CENTER);
        dialog.add(bottomPanel, BorderLayout.SOUTH);

        dialog.setVisible(true);
    }

    // =====================================
    // CREATE / EDIT LETTER WINDOW
    // =====================================

    private void openEditor(Letter existingLetter) {

        boolean editing = existingLetter != null;

        JDialog dialog = new JDialog(
                SwingUtilities.getWindowAncestor(this),
                editing ? "Edit Letter" : "Create New Letter",
                Dialog.ModalityType.APPLICATION_MODAL
        );

        dialog.setSize(750, 600);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(10, 10));

        dialog.getContentPane().setBackground(
                new Color(250, 248, 245)
        );

        // TITLE FIELD
        JTextField titleField = new JTextField();

        titleField.setFont(
                new Font("Arial", Font.PLAIN, 17)
        );

        // MESSAGE FIELD
        JTextArea messageArea = new JTextArea();

        messageArea.setFont(
                new Font("Arial", Font.PLAIN, 16)
        );
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);

        // Fill in existing letter when editing
        if (editing) {
            titleField.setText(existingLetter.title);
            messageArea.setText(existingLetter.message);
        }

        JScrollPane messageScroll = new JScrollPane(messageArea);

        // INPUT PANEL
        JPanel inputPanel = new JPanel(
                new BorderLayout(5, 10)
        );

        inputPanel.setOpaque(false);
        inputPanel.setBorder(
                new EmptyBorder(20, 25, 10, 25)
        );

        JPanel titlePanel = new JPanel(new BorderLayout(5, 5));
        titlePanel.setOpaque(false);
        titlePanel.add(
                new JLabel("Letter Title:"),
                BorderLayout.NORTH
        );
        titlePanel.add(titleField, BorderLayout.CENTER);

        JPanel writingPanel = new JPanel(new BorderLayout(5, 5));
        writingPanel.setOpaque(false);
        writingPanel.add(
                new JLabel("Your Letter:"),
                BorderLayout.NORTH
        );
        writingPanel.add(messageScroll, BorderLayout.CENTER);

        inputPanel.add(titlePanel, BorderLayout.NORTH);
        inputPanel.add(writingPanel, BorderLayout.CENTER);

        // SAVE BUTTON
        JButton saveButton = new JButton(
                editing ? "Save Changes" : "Save Letter"
        );

        saveButton.setFont(
                new Font("Arial", Font.BOLD, 14)
        );
        saveButton.setFocusPainted(false);

        saveButton.addActionListener(e -> {

            String newTitle = titleField.getText().trim();
            String newMessage = messageArea.getText().trim();

            if (newTitle.isEmpty()) {
                JOptionPane.showMessageDialog(
                        dialog,
                        "Please enter a letter title."
                );
                return;
            }

            if (newMessage.isEmpty()) {
                JOptionPane.showMessageDialog(
                        dialog,
                        "Please enter a letter message."
                );
                return;
            }

            if (editing) {
                existingLetter.title = newTitle;
                existingLetter.message = newMessage;
            } else {
                letters.add(new Letter(newTitle, newMessage));
            }

            saveLetters();
            refreshLetters();

            dialog.dispose();
        });

        JPanel bottomPanel = new JPanel(
                new FlowLayout(FlowLayout.RIGHT)
        );
        bottomPanel.setOpaque(false);
        bottomPanel.setBorder(
                new EmptyBorder(5, 25, 15, 25)
        );
        bottomPanel.add(saveButton);

        dialog.add(inputPanel, BorderLayout.CENTER);
        dialog.add(bottomPanel, BorderLayout.SOUTH);

        dialog.setVisible(true);
    }
}
