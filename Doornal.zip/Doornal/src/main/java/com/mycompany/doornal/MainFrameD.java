package com.mycompany.doornal;



import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JFrame;
import javax.swing.JPanel;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Hp
 */



public class MainFrameD extends JFrame {

    private CardLayout cardLayout;
    private JPanel mainContent;

    public MainFrameD() {

        setTitle("Doornal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());


        cardLayout = new CardLayout();
        mainContent = new JPanel(cardLayout);

        // JOURNAL PANEL

        JPanel journalPanel = new JPanel(new GridBagLayout());
        journalPanel.setBackground(Color.WHITE);

        CalendarPanel calendar = new CalendarPanel();

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(30, 30, 30, 30);

        journalPanel.add(calendar, gbc);

        // LETTERS PANEL

        LettersPanel lettersPanel = new LettersPanel();

            // PANELS
        mainContent.add(journalPanel, "journal");
        mainContent.add(lettersPanel, "letters");
        
        // SIDEBAR
      
        SideBar sidebar = new SideBar();

        // Journal 
        sidebar.getJournalButton().addActionListener(e -> {
            cardLayout.show(mainContent, "journal");
        });

        // Letters 
        sidebar.getLettersButton().addActionListener(e -> {
            cardLayout.show(mainContent, "letters");
        });

        add(sidebar, BorderLayout.WEST);
        add(mainContent, BorderLayout.CENTER);

        cardLayout.show(mainContent, "journal");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }
}

