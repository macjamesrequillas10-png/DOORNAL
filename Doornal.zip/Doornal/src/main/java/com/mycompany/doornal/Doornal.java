/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.doornal;

/**
 *
 * @author Hp
 */


import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.Locale;

public class Doornal {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrameD());
    }
}

