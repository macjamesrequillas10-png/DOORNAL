
package com.mycompany.doornal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Hp
 */


public class SideBar extends JPanel {

    private JButton accountButton;
    private JButton journalButton;
    private JButton lettersButton;

    public SideBar() {

        setPreferredSize(new Dimension(180, 0));
        setLayout(new BorderLayout());

        Color sidebarColor = new Color(240, 240, 240);
        setBackground(sidebarColor);

        // =========================
        // TOP SECTION
        // =========================

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setBackground(sidebarColor);

        JLabel logo = new JLabel("DOORNAL");
        logo.setFont(new Font("Arial", Font.BOLD, 20));
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);

        topPanel.add(Box.createVerticalStrut(30));
        topPanel.add(logo);
        topPanel.add(Box.createVerticalStrut(40));

        // =========================
        // NAVIGATION BUTTONS
        // =========================

        accountButton = createButton("Account");
        journalButton = createButton("Journal");
        lettersButton = createButton("Letters");

        topPanel.add(accountButton);
        topPanel.add(Box.createVerticalStrut(10));

        topPanel.add(journalButton);
        topPanel.add(Box.createVerticalStrut(10));

        topPanel.add(lettersButton);
        topPanel.add(Box.createVerticalStrut(10));

        add(topPanel, BorderLayout.NORTH);
    }

    // Button design
    private JButton createButton(String text) {

        JButton button = new JButton(text);

        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(150, 40));
        button.setPreferredSize(new Dimension(150, 40));
        button.setMinimumSize(new Dimension(150, 40));
        button.setFocusPainted(false);

        return button;
    }

    // =========================
    // BUTTON GETTERS
    // =========================

    public JButton getAccountButton() {
        return accountButton;
    }

    public JButton getJournalButton() {
        return journalButton;
    }

    public JButton getLettersButton() {
        return lettersButton;
    }
}
