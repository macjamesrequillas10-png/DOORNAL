/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.doornal;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
/**
 *
 * @author Hp
 */
public class JournalEditor extends JFrame {

    private JTextArea journalArea;
    private JLabel statusLabel;

    private LocalDate journalDate;
    private Path journalFile;

    public JournalEditor(LocalDate date) {

        journalDate = date;

        // =================================
        // WINDOW SETTINGS
        // =================================

        setTitle("Doornal - Journal");
        setSize(700, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setLayout(new BorderLayout(15, 15));

        // =================================
        // JOURNAL FILE LOCATION
        // =================================

        Path journalFolder = Path.of(
                System.getProperty("user.home"),
                "Doornal",
                "Journals"
        );

        journalFile = journalFolder.resolve(date + ".txt");

        // =================================
        // HEADER
        // =================================

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBorder(
                BorderFactory.createEmptyBorder(20, 20, 10, 20)
        );

        JLabel dateLabel = new JLabel(
                date.format(DateTimeFormatter.ofPattern("MMMM dd, yyyy"))
        );

        dateLabel.setFont(new Font("Arial", Font.BOLD, 24));

        headerPanel.add(dateLabel, BorderLayout.WEST);

        add(headerPanel, BorderLayout.NORTH);

        // =================================
        // JOURNAL TEXT AREA
        // =================================

        journalArea = new JTextArea();

        journalArea.setFont(new Font("Arial", Font.PLAIN, 16));
        journalArea.setLineWrap(true);
        journalArea.setWrapStyleWord(true);
        journalArea.setMargin(new Insets(15, 15, 15, 15));

        JScrollPane scrollPane = new JScrollPane(journalArea);

        scrollPane.setBorder(
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        );

        add(scrollPane, BorderLayout.CENTER);

        // =================================
        // FOOTER
        // =================================

        JPanel footerPanel = new JPanel(new BorderLayout());

        footerPanel.setBorder(
                BorderFactory.createEmptyBorder(10, 20, 20, 20)
        );

        statusLabel = new JLabel("Saved");

        JButton saveButton = new JButton("Save");

        saveButton.addActionListener(e -> {
            if (saveEntry()) {
                statusLabel.setText("Saved successfully!");
            }
        });

        footerPanel.add(statusLabel, BorderLayout.WEST);
        footerPanel.add(saveButton, BorderLayout.EAST);

        add(footerPanel, BorderLayout.SOUTH);

        // =================================
        // LOAD PREVIOUS JOURNAL ENTRY
        // =================================

        loadEntry();

        // =================================
        // AUTOMATIC SAVING
        // =================================

        journalArea.getDocument().addDocumentListener(
                new DocumentListener() {

            private void saveAutomatically() {
                if (saveEntry()) {
                    statusLabel.setText("Saved");
                } else {
                    statusLabel.setText("Unable to save");
                }
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                saveAutomatically();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                saveAutomatically();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                saveAutomatically();
            }
        });

        // Save when the journal window closes

        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                saveEntry();
            }
        });
    }

    // =================================
    // LOAD JOURNAL ENTRY
    // =================================

    private void loadEntry() {

        try {

            Files.createDirectories(journalFile.getParent());

            if (Files.exists(journalFile)) {

                String savedText = Files.readString(journalFile);

                journalArea.setText(savedText);

            }

        } catch (IOException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to load journal entry.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // =================================
    // SAVE JOURNAL ENTRY
    // =================================

    private boolean saveEntry() {

        try {

            Files.createDirectories(journalFile.getParent());

            Files.writeString(
                    journalFile,
                    journalArea.getText()
            );

            return true;

        } catch (IOException e) {

            e.printStackTrace();
            return false;
        }
    }
}
