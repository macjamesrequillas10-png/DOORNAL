/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.doornal;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.Locale;
/**
 *
 * @author Hp
 */


public class CalendarPanel extends JPanel {

    private YearMonth currentMonth;
    private JLabel monthLabel;
    private JPanel datesPanel;

    private LocalDate selectedDate;

    private final int cornerRadius = 18;

    private final Color outlineColor = new Color(190, 190, 190);
    private final Color panelColor = new Color(250, 250, 250);
    private final Color selectedColor = new Color(210, 225, 245);
    private final Color todayColor = new Color(225, 235, 250);

    public CalendarPanel() {

        currentMonth = YearMonth.from(LocalDate.now());
        selectedDate = LocalDate.now();

        setLayout(new BorderLayout(15, 15));
        setPreferredSize(new Dimension(650, 550));
        setOpaque(false);

        setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

 
        
        
        
        

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JButton previousButton = new JButton("<");
        JButton nextButton = new JButton(">");

        monthLabel = new JLabel("", SwingConstants.CENTER);
        monthLabel.setFont(new Font("Arial", Font.BOLD, 24));

        styleArrowButton(previousButton);
        styleArrowButton(nextButton);

        previousButton.addActionListener(e -> {
            currentMonth = currentMonth.minusMonths(1);
            updateCalendar();
        });

        nextButton.addActionListener(e -> {
            currentMonth = currentMonth.plusMonths(1);
            updateCalendar();
        });

        headerPanel.add(previousButton, BorderLayout.WEST);
        headerPanel.add(monthLabel, BorderLayout.CENTER);
        headerPanel.add(nextButton, BorderLayout.EAST);

        add(headerPanel, BorderLayout.NORTH);

   
        
        

        datesPanel = new JPanel(new GridLayout(0, 7, 10, 10));
        datesPanel.setOpaque(false);

        add(datesPanel, BorderLayout.CENTER);

        updateCalendar();
    }


    
    
    private void updateCalendar() {

        datesPanel.removeAll();

        monthLabel.setText(
                currentMonth.getMonth().getDisplayName(
                        TextStyle.FULL, Locale.ENGLISH
                ) + " " + currentMonth.getYear()
        );


        String[] weekdays = {
            "Sun", "Mon", "Tue", "Wed",
            "Thu", "Fri", "Sat"
        };

        for (String day : weekdays) {

            JLabel label = new JLabel(day, SwingConstants.CENTER);

            label.setFont(new Font("Arial", Font.BOLD, 14));
            label.setForeground(Color.DARK_GRAY);

            datesPanel.add(label);
        }


        LocalDate firstDay = currentMonth.atDay(1);

        int startingDay = firstDay.getDayOfWeek().getValue() % 7;


        for (int i = 0; i < startingDay; i++) {
            datesPanel.add(new JLabel(""));
        }


        int daysInMonth = currentMonth.lengthOfMonth();

        LocalDate today = LocalDate.now();
        //everyday iz yo birthday ashita blabal shinaite OOHHHHHH!!!

        for (int day = 1; day <= daysInMonth; day++) {

            LocalDate date = currentMonth.atDay(day);

            JButton dayButton = new JButton(String.valueOf(day));

            dayButton.setFont(new Font("Arial", Font.PLAIN, 16));
            dayButton.setFocusPainted(false);
            dayButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

            dayButton.setBorder(BorderFactory.createLineBorder(
                    new Color(220, 220, 220), 1
            ));

            dayButton.setOpaque(true);

            if (date.equals(today)) {
                dayButton.setBackground(todayColor);
                dayButton.setFont(new Font("Arial", Font.BOLD, 16));
            } else {
                dayButton.setBackground(Color.WHITE);
            }
            
            if (date.equals(selectedDate)) {
                dayButton.setBackground(selectedColor);
                dayButton.setFont(new Font("Arial", Font.BOLD, 16));
            }


            dayButton.addActionListener(e -> {

          selectedDate = date;

          updateCalendar();

          JournalEditor editor = new JournalEditor(date);
          editor.setVisible(true);
}); //i am calm and collected that is what the c in caitlyn sstands for.

            datesPanel.add(dayButton);
        }

        datesPanel.revalidate();
        datesPanel.repaint();
    }

 

    private void styleArrowButton(JButton button) {

        button.setFont(new Font("Arial", Font.BOLD, 20));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }


    @Override
    protected void paintComponent(Graphics g) {

        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
        );

        g2.setColor(panelColor);

        g2.fill(new RoundRectangle2D.Float(
                0, 0, getWidth(), getHeight(),
                cornerRadius, cornerRadius
        ));

        g2.setColor(outlineColor);
        g2.setStroke(new BasicStroke(1));

        g2.draw(new RoundRectangle2D.Float(
                0, 0, getWidth() - 1, getHeight() - 1,
                cornerRadius, cornerRadius
        ));

        g2.dispose();
    }
}
